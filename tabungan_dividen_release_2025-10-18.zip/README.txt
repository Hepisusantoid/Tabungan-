# Tabungan v2 — Rilis Dividen (2025-10-18)
Fitur:
- Saldo Dividen (publik & admin)
- Pie kepemilikan: publik “[Nama] x% vs Lainnya y%” dan admin “top 8 + Lainnya”
- Form Penghasilan → bagi proporsional → catat riwayat `dividen` (tanpa mengubah saldo/lots)

Cara pasang (singkat):
1) Ganti file di root project dengan file-file dari ZIP ini:
   - index.html, style.dividen.css, app.dividen.js
   - /api/get.js, /api/put.js, /api/public.js, /api/login.js, /api/debug.js
2) Set ENV di Vercel (Production & Preview):
   - JSONBIN_BASE=https://api.jsonbin.io/v3
   - JSONBIN_BIN_ID=<ID>
   - JSONBIN_MASTER_KEY=<MASTER KEY>
   - ADMIN_USER=<user>, ADMIN_PASS=<pass>
3) Deploy → buka /api/debug (semua true) → buka /?bust=2025-10-18a
