export const config = { runtime: 'nodejs' };
export default async function handler(req, res) {
  const { JSONBIN_BASE, JSONBIN_BIN_ID, JSONBIN_MASTER_KEY, ADMIN_USER, ADMIN_PASS } = process.env;
  res.status(200).json({
    JSONBIN_BASE: !!JSONBIN_BASE,
    JSONBIN_BIN_ID: !!JSONBIN_BIN_ID,
    JSONBIN_MASTER_KEY: !!JSONBIN_MASTER_KEY,
    ADMIN_USER: !!ADMIN_USER,
    ADMIN_PASS: !!ADMIN_PASS,
    timestamp: new Date().toISOString()
  });
}
